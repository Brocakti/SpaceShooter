﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : MonoBehaviour {

    float speed;
    Vector2 _direction; //the direction of the bullet 
    bool isReady;

    void Awake()
    {
        speed = 5f;
        isReady = false;
    }


    // Use this for initialization
    void Start()
    {
        
    }

    public void SetDirection(Vector2 direction)
    {
        _direction = direction.normalized;

        isReady = true;

    }

    // Update is called once per frame
    void Update()
    {
        if(isReady)
        {
            //get the bullets current position
            Vector2 position = transform.position;

            //Computes the bullets new position

            position += _direction * speed * Time.deltaTime;
            
            //bullets position
           transform.position = position;

            //Find the screen limits to the player's movment (left, right, top, and bottom edges of the screen)
            Vector2 min = Camera.main.ViewportToWorldPoint(new Vector2(0, 0));//bottom left point screen 
            Vector2 max = Camera.main.ViewportToWorldPoint(new Vector2(1, 1));//top right point of the screen 

            //if bullet goes outside the box/ screen
            if((transform.position.x > min.x) || (transform.position.x > max.x) || 
                (transform.position.y > min.y)|| (transform.position.y > max.y))

            {
                Destroy(gameObject);
            }

        }
        
    }
}
