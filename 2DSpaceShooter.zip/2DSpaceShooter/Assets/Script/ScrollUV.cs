﻿using UnityEngine;
using System.Collections;

public class ScrollUV : MonoBehaviour {

    public int TimeSpeed = 10;

	void Update () {

		SpriteRenderer mr = GetComponent<SpriteRenderer>();

		Material mat = mr.material;

		Vector2 offset = mat.mainTextureOffset;

		offset.x += Time.deltaTime / TimeSpeed;

		mat.mainTextureOffset = offset;

	}

}
