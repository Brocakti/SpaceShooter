﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{

    public GameObject Enemy; //this is the enemy

    public float maxSpawnRateInSeconds = 5f;

	// Use this for initialization
	void Start ()
    {

       Invoke("SpawnEnemy", maxSpawnRateInSeconds);

        InvokeRepeating("IncreaseSpawnRate", 0f, 30f);
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    //Functions to spawn an enemy
    void SpawnEnemy()
    {
        //Find the screen limits to the player's movment (left, right, top, and bottom edges of the screen)
        Vector2 min = Camera.main.ViewportToWorldPoint(new Vector2(0, 0));//bottom left point screen 
        Vector2 max = Camera.main.ViewportToWorldPoint(new Vector2(1, 1));//top right point of the screen 

        //instantiate an enemy
        GameObject anEnemy = (GameObject)Instantiate(Enemy);
        anEnemy.transform.position = new Vector2(max.x, Random.Range(min.y, max.y));


        ShceduletNextEnemySpawn();


    }


    void ShceduletNextEnemySpawn()
    {
        float spawnInNSeconds;

        if (maxSpawnRateInSeconds > 1f)
        {
            spawnInNSeconds = Random.Range(1f, maxSpawnRateInSeconds);

        }
        else
            spawnInNSeconds = 1f;

        Invoke("SpawnEnemy", spawnInNSeconds);

    }



    void IncraseSpawnRate()
    {
        if (maxSpawnRateInSeconds > 1f)
            maxSpawnRateInSeconds--;


        if (maxSpawnRateInSeconds == 1f)
            CancelInvoke("IncraseSpawnRate");
    }
}
