﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    public float speed;

    public GameObject Bullet;// this is the Bullet Prefab
    public GameObject BulletPosition01;
    public GameObject BulletPosition02;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {



        if(Input.GetKeyDown("space"))
        {
            //instatiete the first bullet
            GameObject bullet01 = (GameObject)Instantiate(Bullet);
            bullet01.transform.position = BulletPosition01.transform.position;//sets the bullet initail position

            //instatiete the second bullet
            GameObject bullet02 = (GameObject)Instantiate(Bullet);
            bullet02.transform.position = BulletPosition01.transform.position;//sets the bullet initail position



        }

        float x = Input.GetAxisRaw("Horizontal");
        float y = Input.GetAxisRaw("Vertical");

        //now based on the input it computes a direct vector, and it normalizes it to get a unit vector
        Vector2 direction = new Vector2(x, y).normalized;

        //this calls the function that computes and sets the player's position
        Move (direction);

	}

    void Move(Vector2 direction)
    {
        //Find the screen limits to the player's movment (left, right, top, and bottom edges of the screen)
        Vector2 min = Camera.main.ViewportToWorldPoint(new Vector2(0, 0));//bottom left point screen 
        Vector2 max = Camera.main.ViewportToWorldPoint(new Vector2(1, 1));//top right point of the screen 
        

        max.x = max.x - 0.225f;//subtract the player sprite half width 
        min.x = min.x + 0.225f;//add the player sprite half width 

        max.y = max.y - 0.285f;//subtract the player sprite half heght
        min.y = min.y + 0.285f;//add the player sprite half height

        //Get the Player's current position
        Vector2 pos = transform.position;



        //Calculate the new position
        pos += direction * speed * Time.deltaTime;

        //Make's sure that the new position is not outside the screen 
        pos.x = Mathf.Clamp(pos.x, min.x, max.x);
        pos.y = Mathf.Clamp(pos.y, min.y, max.y);

        // Updates the player's positio
        transform.position = pos;
    }
}
