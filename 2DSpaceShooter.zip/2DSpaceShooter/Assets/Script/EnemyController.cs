﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public float speed; // for the enemy speed

	// Use this for initialization
	void Start () {
        //speed = ;// speed
	}
	
	// Update is called once per frame
	void Update () {

        //get the enemy position
        Vector2 position = transform.position;

        //Computer the enmy new position
        position = new Vector2(position.x - speed * Time.deltaTime, position.y);

        //Update the enemy position 
        transform.position = position;

        //this is the went Bottom left point of the screen 
        Vector2 min = Camera.main.ViewportToWorldPoint(new Vector2(0, 0));

        //if the enemy goes off the screen destroys the enemy
        if( transform.position.x < min.x)
        {
            Destroy(gameObject);
        }

	}
}
